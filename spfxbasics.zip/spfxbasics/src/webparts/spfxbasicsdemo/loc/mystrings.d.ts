declare interface ISpfxbasicsdemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpfxbasicsdemoWebPartStrings' {
  const strings: ISpfxbasicsdemoWebPartStrings;
  export = strings;
}
