/* tslint:disable */
require("./SpfxbasicsdemoWebPart.module.css");
const styles = {
  spfxbasicsdemo: 'spfxbasicsdemo_f8da82e0',
  container: 'container_f8da82e0',
  row: 'row_f8da82e0',
  column: 'column_f8da82e0',
  'ms-Grid': 'ms-Grid_f8da82e0',
  title: 'title_f8da82e0',
  subTitle: 'subTitle_f8da82e0',
  description: 'description_f8da82e0',
  button: 'button_f8da82e0',
  label: 'label_f8da82e0'
};

export default styles;
/* tslint:enable */