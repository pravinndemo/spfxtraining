import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface ISpfxbasicsdemoWebPartProps {
    description: string;
    environmenttitle: string;
}
export default class SpfxbasicsdemoWebPart extends BaseClientSideWebPart<ISpfxbasicsdemoWebPartProps> {
    private findOutEnvironment;
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=SpfxbasicsdemoWebPart.d.ts.map